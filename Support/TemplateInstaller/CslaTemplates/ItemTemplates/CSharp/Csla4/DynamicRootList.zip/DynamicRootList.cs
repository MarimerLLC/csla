using System;
using System.Collections.Generic;
using Csla;

namespace $rootnamespace$
{
  [Serializable]
  public class $safeitemname$ :
    DynamicListBase<DynamicRoot>
  {
    #region Business Methods

    protected override DynamicRoot AddNewCore()
    {
      var item = DynamicRoot.NewDynamicRoot();
      Add(item);
      return item;
    }

    #endregion

    #region  Authorization Rules

    private static void AddObjectAuthorizationRules()
    {
      // TODO: add authorization rules
      //AuthorizationRules.AllowGet(typeof($safeitemname$), "Role");
      //AuthorizationRules.AllowEdit(typeof($safeitemname$), "Role");
    }

    #endregion

    #region  Factory Methods

    public static $safeitemname$ NewDynamicRootList()
    {
      return DataPortal.Create<$safeitemname$>();
    }

    public static $safeitemname$ GetDynamicRootList()
    {
      return DataPortal.Fetch<$safeitemname$>();
    }

    private $safeitemname$()
    {
      // require use of factory methods
      AllowNew = true;
    }

    #endregion

    #region  Data Access

    private void DataPortal_Fetch()
    {
      // TODO: load values
      RaiseListChangedEvents = false;
      object listData = null;
      foreach (var item in (List<object>)listData)
        Add(DynamicRoot.GetDynamicRoot(item));
      RaiseListChangedEvents = true;
    }

    #endregion
  }
}