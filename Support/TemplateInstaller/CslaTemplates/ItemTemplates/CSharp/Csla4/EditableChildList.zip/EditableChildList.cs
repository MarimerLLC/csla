using System;
using System.Collections.Generic;
using Csla;

namespace $rootnamespace$
{
  [Serializable]
  public class $safeitemname$ : 
    BusinessListBase<$safeitemname$, EditableChild>
  {
    #region Factory Methods

    internal static $safeitemname$ NewEditableChildList()
    {
      return DataPortal.CreateChild<$safeitemname$>();
    }

    internal static $safeitemname$ GetEditableChildList(
      object childData)
    {
      return DataPortal.FetchChild<$safeitemname$>(childData);
    }

    private $safeitemname$()
    { }

    #endregion

    #region Data Access

    private void Child_Fetch(object childData)
    {
      RaiseListChangedEvents = false;
      foreach (var child in (IList<object>)childData)
        this.Add(EditableChild.GetEditableChild(child));
      RaiseListChangedEvents = true;
    }

    #endregion
  }
}
