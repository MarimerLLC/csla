using System;
using System.Collections.Generic;
using System.Linq;
using Csla;
using Csla.Server;

namespace $rootnamespace$
{
    public class $safeitemname$ : Csla.Server.ObjectFactory
    {
        // Use snippets 
        //    cslaof     - to add Create/Fetch/Update/Delete methods to factory (for editable objects)
        //    cslaofro   - to add Create/Fetch methods (for readonly objects)
    }
}
