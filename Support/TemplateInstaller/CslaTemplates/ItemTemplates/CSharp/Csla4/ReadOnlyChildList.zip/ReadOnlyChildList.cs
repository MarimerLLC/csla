﻿using System;
using System.Collections.Generic;
using Csla;

namespace $rootnamespace$
{
  [Serializable]
  public class $safeitemname$ :
    ReadOnlyListBase<$safeitemname$, ReadOnlyChild>
  {
    #region Authorization Rules

    private static void AddObjectAuthorizationRules()
    {
      // TODO: add authorization rules
      //AuthorizationRules.AllowGet(typeof($safeitemname$), "Role");
    }

    #endregion

    #region Factory Methods

    internal static $safeitemname$ GetReadOnlyChildList(object childData)
    {
      return DataPortal.FetchChild<$safeitemname$>(childData);
    }

    private $safeitemname$()
    { /* require use of factory methods */ }

    #endregion

    #region Data Access

    private void Child_Fetch(object childData)
    {
      RaiseListChangedEvents = false;
      IsReadOnly = false;
      // TODO: load values
      foreach (var child in (List<object>)childData)
        Add(ReadOnlyChild.GetReadOnlyChild(child));
      IsReadOnly = true;
      RaiseListChangedEvents = true;
    }

    #endregion
  }
}
